const fs = require('fs');
const https = require('https');
const crypto = require('crypto');
const { spawn, execSync } = require('child_process');

// ====== تنظیمات قابل تغییر ======
const WSPATH = '/api/v2/telemetry/stream_8f91a';       // مسیر WebSocket
const PORT = process.env.SERVER_PORT || process.env.PORT || 3000;
const UUID_FILE = './uuid.txt';                         // فایل ذخیره UUID
// ==================================

// ====== تابع ساخت UUID جدید ======
function generateUUID() {
    return crypto.randomUUID();
}

// ====== تابع خواندن یا ساخت UUID ======
function getOrCreateUUID() {
    if (fs.existsSync(UUID_FILE)) {
        const saved = fs.readFileSync(UUID_FILE, 'utf8').trim();
        if (saved && saved.length === 36) {
            console.log('=== UUID loaded from file ===');
            return saved;
        }
    }
    const newUUID = generateUUID();
    fs.writeFileSync(UUID_FILE, newUUID);
    console.log('=== New UUID generated and saved ===');
    return newUUID;
}

// ====== تابع پیدا کردن آی‌پی عمومی ======
function getPublicIP() {
    return new Promise((resolve) => {
        console.log('=== Detecting public IP... ===');
        
        const services = [
            'https://api.ipify.org',
            'https://ifconfig.me/ip',
            'https://icanhazip.com',
            'https://checkip.amazonaws.com'
        ];
        
        let index = 0;
        
        function tryNext() {
            if (index >= services.length) {
                console.log('=== Could not detect public IP. ===');
                resolve(null);
                return;
            }
            
            const url = services[index];
            index++;
            
            const req = https.get(url, { timeout: 5000 }, (res) => {
                let data = '';
                res.on('data', (chunk) => data += chunk);
                res.on('end', () => {
                    const ip = data.trim();
                    if (ip && /^[\d.:a-fA-F]+$/.test(ip)) {
                        resolve(ip);
                    } else {
                        tryNext();
                    }
                });
            });
            
            req.on('error', () => tryNext());
            req.on('timeout', () => {
                req.destroy();
                tryNext();
            });
        }
        
        tryNext();
    });
}

// ====== تابع ساخت لینک VLESS ======
function buildVlessLink(ip, port, uuid, path) {
    const encodedPath = encodeURIComponent(path);
    return `vless://${uuid}@${ip}:${port}?encryption=none&security=none&type=ws&path=${encodedPath}&host=${ip}#AutoServer`;
}

// ====== تابع اصلی ======
async function main() {
    console.log('========================================');
    console.log('   VLESS Auto-Setup Script');
    console.log('========================================');
    
    // ۱. UUID
    const UUID = getOrCreateUUID();
    
    // ۲. آی‌پی عمومی
    const publicIP = await getPublicIP();
    
    // ۳. نمایش اطلاعات
    console.log('========================================');
    console.log(`[★] UUID: ${UUID}`);
    console.log(`[★] Port: ${PORT}`);
    console.log(`[★] Path: ${WSPATH}`);
    if (publicIP) {
        console.log(`[★] Public IP: ${publicIP}`);
        console.log('========================================');
        console.log('[★] VLESS LINK (copy this):');
        console.log('----------------------------------------');
        console.log(buildVlessLink(publicIP, PORT, UUID, WSPATH));
        console.log('----------------------------------------');
    } else {
        console.log('[!] Public IP not detected. Please find it manually.');
    }
    console.log('========================================');
    
    // ۴. چک کردن فایل Xray
    if (!fs.existsSync('./xray')) {
        console.error('ERROR: Xray binary not found! Please upload it manually.');
        process.exit(1);
    } else {
        console.log('=== Xray binary found ===');
        try {
            execSync('chmod +x ./xray');
            console.log('=== Execute permission granted ===');
        } catch (e) {
            console.error('Failed to chmod:', e.message);
        }
    }
    
    // ۵. ساخت کانفیگ
    const config = {
        "log": { "loglevel": "warning" },
        "dns": {
            "servers": [
                {
                    "address": "1.1.1.1",
                    "domains": ["geosite:geolocation-!cn"]
                },
                {
                    "address": "8.8.8.8",
                    "domains": ["geosite:geolocation-!cn"]
                },
                "localhost"
            ]
        },
        "inbounds": [{
            "port": PORT,
            "listen": "0.0.0.0",
            "protocol": "vless",
            "settings": {
                "clients": [{ "id": UUID }],
                "decryption": "none"
            },
            "streamSettings": {
                "network": "ws",
                "wsSettings": { "path": WSPATH }
            },
            "sniffing": {
                "enabled": true,
                "destOverride": ["http", "tls", "quic"]
            }
        }],
        "outbounds": [
            {
                "protocol": "freedom",
                "settings": {
                    "domainStrategy": "UseIP"
                }
            }
        ]
    };
    
    fs.writeFileSync('config.json', JSON.stringify(config, null, 2));
    console.log('=== Config ready ===');
    
    // ۶. اجرای Xray
    console.log(`=== Starting Xray on port ${PORT} ===`);
    const xray = spawn('./xray', ['-c', 'config.json'], { stdio: 'inherit' });
    
    xray.on('error', (err) => {
        console.error('Failed to start Xray:', err.message);
        process.exit(1);
    });
    
    xray.on('close', (code) => {
        console.log(`Xray exited with code ${code}`);
        process.exit(code);
    });
    
    process.on('SIGTERM', () => {
        xray.kill();
        process.exit(0);
    });
    
    process.on('SIGINT', () => {
        xray.kill();
        process.exit(0);
    });
}

main();